import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { log } from '../../lib/utils/logger';
import type { Message } from '../chat/types';



/**
 * A hook for fetching messages for the active conversation.
 * @param userId - The ID of the current user.
 * @param activeId - The active conversation ID.
 * @param connectionError - Whether there is a connection error.
 * @param setConnectionError - A function to set the connection error.
 * @returns The messages, a function to update them, and an error.
 */
export function useMessages(userId: string | null, activeId: string, connectionError: boolean, setConnectionError: (error: boolean) => void) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    if (!userId || !activeId) {
      return;
    }

    if (connectionError) {
      return;
    }

    const fetchMessages = async () => {
      try {
        const { data, error: msgError } = await supabase
          .from("messages")
          .select("*")
          .eq("conversation_id", activeId)
          .order("created_at", { ascending: false })
          .limit(200);

        if (cancelled) return;

        if (msgError) {
          const isNetworkError = msgError.message?.includes('Failed to fetch') || msgError.message?.includes('NetworkError') || !msgError.code;
          if (isNetworkError) {
            setConnectionError(true);
            setError('Unable to connect to database. Please check your connection and refresh the page.');
          } else {
            setError(`Failed to load messages: ${msgError.message || 'Unknown error'}`);
          }
          return;
        }

        if (data) {
          const processedMessages = data.map(msg => {
            if (msg.content && msg.content.length > 50000) {
              return {
                ...msg,
                content: msg.content.substring(0, 50000) + '\n\n... [Message truncated due to size. Original length: ' + msg.content.length + ' characters]'
              };
            }
            return msg;
          });

          const conversationData = {
            id: activeId,
            user_id: userId,
            created_at: new Date().toISOString(),
            messages: processedMessages.map(msg => ({
              id: msg.id,
              role: msg.role,
              content: msg.content,
              metadata: msg.metadata,
              content_json: msg.content_json,
              tools_called: msg.tools_called,
            })),
          };

          // TODO: Add conversation validation when validateMultiple is implemented
          // For now, use processed messages directly
          setMessages([...processedMessages].reverse());
        }
      } catch (err: any) {
        setError(err.message);
      }
    };

    fetchMessages();

    return () => {
      cancelled = true;
    };
  }, [userId, activeId, connectionError, setConnectionError]);

  return { messages, setMessages, error };
}

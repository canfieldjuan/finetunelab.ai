
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { log } from '../../lib/utils/logger';

export function useModelSelection() {
  const [selectedModelId, setSelectedModelId] = useState<string>("__default__");
  const [selectedModel, setSelectedModel] = useState<{ id: string; name: string; context_length: number } | null>(null);
  const [availableModels, setAvailableModels] = useState<Array<{ id: string; name: string }>>([]);

  useEffect(() => {
    const fetchModels = async () => {
      try {
        const { data, error } = await supabase.from('models').select('id, name');
        if (error) {
          throw error;
        }
        setAvailableModels(data || []);
      } catch (err: any) {
        log.error('useModelSelection', 'Error fetching models', { error: err });
      }
    };

    fetchModels();
  }, []);

  const handleModelChange = (modelId: string, model?: { id: string; name: string; context_length: number }) => {
    setSelectedModelId(modelId);
    setSelectedModel(model || null);
  };

  return {
    selectedModelId,
    selectedModel,
    availableModels,
    handleModelChange,
  };
}


import { useState, useCallback, useRef, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { log } from '../../lib/utils/logger';
import type { Message } from '../chat/types';
import type { Citation } from "@/lib/graphrag/service";
import type { User } from '@supabase/supabase-js';
import type { ContextTracker } from '../../lib/context/context-tracker';
import type { ContextUsage } from '@/lib/context/types';


/**
 * Options for the useChat hook.
 */
interface UseChatOptions {
  /** The current user. */
  user: User | null;
  /** The active conversation ID. */
  activeId: string;
  /** The available tools. */
  tools: any[];
  /** Whether deep research is enabled. */
  enableDeepResearch: boolean;
  /** The selected model ID. */
  selectedModelId: string;
  /** A ref to the context tracker. */
  contextTrackerRef: React.MutableRefObject<ContextTracker | null>;
  /** A function to set the context usage. */
  setContextUsage: (usage: ContextUsage | null) => void;
}

/**
 * A hook for managing the chat state and actions.
 * @param options - The options for the hook.
 * @returns The chat state and actions.
 */
export function useChat({ user, activeId, tools, enableDeepResearch, selectedModelId, contextTrackerRef, setContextUsage }: UseChatOptions) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [abortController, setAbortController] = useState<AbortController | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const lastScrolledMessagesLength = useRef<number>(0);

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      if (messagesContainerRef.current) {
        messagesContainerRef.current.scrollTop =
          messagesContainerRef.current.scrollHeight;
      }
      messagesEndRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "end"
      });
    });
  }, []);

  useEffect(() => {
    if (messages.length > 0 && messages.length !== lastScrolledMessagesLength.current) {
      lastScrolledMessagesLength.current = messages.length;
      scrollToBottom();
    }
  }, [messages, scrollToBottom]);

  const saveMessageToDatabase = async (assistantMessage: string, modelId: string | null, provider: string | null, streamLatencyMs: number, userMessage: string) => {
    if (!user) {
      log.warn('useChat', 'Cannot save message - no user');
      return;
    }

    const estimatedOutputTokens = Math.ceil(assistantMessage.length / 4);
    const estimatedInputTokens = Math.ceil(userMessage.length / 4);

    log.debug('useChat', 'Inserting assistant message to database', {
      conversationId: activeId,
      userId: user.id,
      modelId,
      provider,
      contentLength: assistantMessage.length
    });

    const { data: aiMsg, error: dbError } = await supabase
      .from("messages")
      .insert({
        conversation_id: activeId,
        user_id: user.id,
        role: "assistant",
        content: assistantMessage,
        model_id: modelId,
        provider: provider,
        latency_ms: streamLatencyMs,
        input_tokens: estimatedInputTokens,
        output_tokens: estimatedOutputTokens
      })
      .select()
      .single();

    if (dbError) {
      log.error('useChat', 'Failed to save message', { error: dbError });
    } else {
      log.debug('useChat', 'Message saved successfully', { messageId: aiMsg?.id });
    }

    return aiMsg;
  };

  const streamAndProcessResponse = async (response: Response, tempMessageId: string, userMessage: string) => {
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let assistantMessage = "";
    let graphragCitations: Citation[] | undefined;
    let graphragContextsUsed: number | undefined;
    let modelId: string | null = null;
    let provider: string | null = null;
    let updateThrottle: NodeJS.Timeout | null = null;
    const THROTTLE_MS = 500;

    const updateMessageThrottled = () => {
      if (updateThrottle) clearTimeout(updateThrottle);
      updateThrottle = setTimeout(() => {
        setMessages(prev => prev.map((m) => m.id === tempMessageId ? { ...m, content: assistantMessage, citations: graphragCitations, contextsUsed: graphragContextsUsed } : m));
      }, THROTTLE_MS);
    };

    if (reader) {
      streamLoop: while (true) {
        const { done, value } = await reader.read();
        if (done) {
          break streamLoop;
        }
        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6);
          if (data === "[DONE]") {
            break streamLoop;
          }
          try {
            const parsed = JSON.parse(data);
            if (parsed.type === "graphrag_metadata") {
              graphragCitations = parsed.citations;
              graphragContextsUsed = parsed.contextsUsed;
              setMessages(prev => prev.map((m) => m.id === tempMessageId ? { ...m, citations: graphragCitations, contextsUsed: graphragContextsUsed } : m));
            }
            if (parsed.content) {
              assistantMessage += parsed.content;
              updateMessageThrottled();
            }
            if (parsed.type === "model_metadata") {
              modelId = parsed.model_id;
              provider = parsed.provider;
            }
            if (parsed.type === "token_usage" && contextTrackerRef.current) {
              const inputTokens = parsed.input_tokens || 0;
              const outputTokens = parsed.output_tokens || 0;
              const graphragTokens = parsed.graphrag_tokens || 0;
              const updatedUsage = contextTrackerRef.current.addMessage(inputTokens, outputTokens, graphragTokens);
              setContextUsage(updatedUsage);
              const isValidUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(selectedModelId);
              if (selectedModelId !== '__default__' && activeId && isValidUUID) {
                const activeContext = contextTrackerRef.current.getModelContext(selectedModelId === '__default__' ? null : selectedModelId);
                if (activeContext) {
                  supabase.from('conversation_model_contexts').upsert({ conversation_id: activeId, model_id: selectedModelId, total_tokens: activeContext.totalTokens, input_tokens: activeContext.inputTokens, output_tokens: activeContext.outputTokens, graphrag_tokens: activeContext.graphragTokens, message_count: activeContext.messageCount, first_message_at: activeContext.firstMessageAt?.toISOString(), last_message_at: activeContext.lastMessageAt?.toISOString(), }, { onConflict: 'conversation_id,model_id' }).then(({ error }) => {
                    if (error) {
                      log.error('useChat', 'Error saving context', { error, modelId: selectedModelId, conversationId: activeId, errorCode: error.code, errorMessage: error.message, errorDetails: error.details, errorHint: error.hint });
                    }
                  });
                }
              }
            }
          } catch (err) {
            log.warn('useChat', 'Skipping invalid JSON chunk', { error: err });
          }
        }
      }
    }

    if (updateThrottle) {
      clearTimeout(updateThrottle);
    }

    const streamLatencyMs = Date.now() - (response as any).startTime;
    log.debug('useChat', 'About to save message to database', { tempMessageId, assistantMessageLength: assistantMessage.length });
    const aiMsg = await saveMessageToDatabase(assistantMessage, modelId, provider, streamLatencyMs, userMessage);
    log.debug('useChat', 'Database save completed', { aiMsg: aiMsg?.id });

    if (aiMsg) {
      setMessages(prev => prev.map((m) => m.id === tempMessageId ? { ...aiMsg, citations: graphragCitations, contextsUsed: graphragContextsUsed } : m));
      log.debug('useChat', 'Message updated with real ID', { realId: aiMsg.id, tempId: tempMessageId });
    }
  };

  const prepareAndSendMessage = async (input: string) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    const userMessage = input;
    const { data: msgData } = await supabase.from("messages").insert({ conversation_id: activeId, user_id: user.id, role: "user", content: userMessage }).select().single();
    if (msgData) setMessages(prev => [...prev, msgData]);
    if (messages.length === 0 && msgData) {
      await supabase.from("conversations").update({ title: userMessage.slice(0, 50) + (userMessage.length > 50 ? "..." : "") }).eq("id", activeId);
    }

    const conversationMessages = [...messages, msgData].map((m) => ({ role: m.role, content: m.content }));
    const modifiedTools = tools.map(tool => {
      if (tool.function.name === 'web_search') {
        let description = tool.function.description;
        description += ' IMPORTANT: Always set summarize=true for enhanced results.';
        if (enableDeepResearch) {
          description += ' IMPORTANT: Deep research mode is ON - you MUST set deepResearchConfirmed=true.';
        }
        return { ...tool, function: { ...tool.function, description } };
      }
      return tool;
    });

    return { conversationMessages, modifiedTools, userMessage };
  };

  const handleSendMessage = async (input: string) => {
    if (!input.trim()) {
      setError("Please enter a message");
      return;
    }
    setLoading(true);
    const controller = new AbortController();
    setAbortController(controller);

    try {
      const { conversationMessages, modifiedTools, userMessage } = await prepareAndSendMessage(input);
      const response = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: conversationMessages, tools: modifiedTools, conversationId: activeId, modelId: selectedModelId === '__default__' ? null : selectedModelId }), signal: controller.signal });
      (response as any).startTime = Date.now();

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to get AI response");
      }

      const tempMessageId = "temp-" + Date.now();
      setMessages(prev => [...prev, { id: tempMessageId, role: "assistant", content: "" }]);
      await streamAndProcessResponse(response, tempMessageId, userMessage);

    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setError(err.message);
      }
    } finally {
      setLoading(false);
      setAbortController(null);
    }
  };

  return {
    input,
    setInput,
    loading,
    setLoading,
    messages,
    setMessages,
    error,
    setError,
    abortController,
    setAbortController,
    messagesEndRef,
    messagesContainerRef,
    handleSendMessage,
  };
}
